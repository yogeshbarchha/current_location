<?php

namespace Drupal\aps_custom\Routing;

use Drupal\Core\Routing\RouteSubscriberBase;
use Symfony\Component\Routing\RouteCollection;

/**
 * Listens to the dynamic route events.
 */
class RouteSubscriber extends RouteSubscriberBase {

  /**
   * {@inheritdoc}
   */
  protected function alterRoutes(RouteCollection $collection) {
    // Always deny access to '/user/logout'.
    // Note that the second parameter of setRequirement() is a string.
    if ($route = $collection->get('user.register')) {
      $route->setDefault('_title_callback','Drupal\aps_custom\Controller\ApsUserController::userRegisterTitle');
    }
    
    if ($route = $collection->get('user.login')) {
      $route->setDefault('_title_callback','Drupal\aps_custom\Controller\ApsUserController::userLoginTitle');
    }
    
    if ($route = $collection->get('user.pass')) {
      $route->setDefault('_title_callback','Drupal\aps_custom\Controller\ApsUserController::userResetTitle'); 
    }
    
    if ($route = $collection->get('entity.user.canonical')) {
      $route->setDefault('_title_callback','Drupal\aps_custom\Controller\ApsUserController::userProfileTitle'); 
    }
  }

}