<?php

namespace Drupal\aps_custom\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\Core\Language\LanguageInterface;

/**
 * Class SettingsForm.
 *
 * @package Drupal\xai\Form
 */
class ApsCustomChangesForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'aps_custom.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('aps_custom.settings');
    $welcome_node = NULL;

    if (!empty($config->get('welcome_node_id'))) {
      $welcome_node_id = $config->get('welcome_node_id');
      $welcome_node = Node::load($welcome_node_id);
    }

    $form['user_register_fieldset'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('User Register'),
    ];
    
    $form['user_register_fieldset']['register_page_title'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Page Title'),
      '#default_value' => $config->get('register_page_title'),
    ];

    $form['user_register_fieldset']['register_username_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t("Username label"),
      '#default_value' => $config->get('register_username_label'),
    ];

    $form['user_register_fieldset']['register_username_description'] = [
      '#type' => 'textarea',
      '#title' => $this->t("Username description"),
      '#default_value' => $config->get('register_username_description'),
    ];

    $form['user_register_fieldset']['register_email_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t("Email label"),
      '#default_value' => $config->get('register_email_label'),
    ];

    $form['user_register_fieldset']['register_email_description'] = [
      '#type' => 'textarea',
      '#title' => $this->t("Email description"),
      '#default_value' => $config->get('register_email_description'),
    ];
    
    $form['user_register_fieldset']['register_email_weight'] = array(
      '#type' => 'number',
      '#title' => $this->t('Email Weight'),
      '#default_value' => $config->get('register_email_weight'),
    );
    
    $form['user_register_fieldset']['register_pass1_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t("Password Label"),
      '#default_value' => $config->get('register_pass1_label'),
    ];
    
    $form['user_register_fieldset']['register_pass2_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t("Confirm Password Label"),
      '#default_value' => $config->get('register_pass2_label'),
    ];
    
    $form['user_register_fieldset']['register_password_weight'] = array(
      '#type' => 'number',
      '#title' => $this->t('Pasword Weight'),
      '#default_value' => $config->get('register_password_weight'),
    );

    $form['user_register_fieldset']['register_submit_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t("Submit label"),
      '#default_value' => $config->get('register_submit_label'),
    ];

    $form['user_register_fieldset']['register_redirect_path'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Register redirect path'),
      '#default_value' => $config->get('register_redirect_path'),
    ];

    $form['user_login_fieldset'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('User Login'),
    ];
    
    $form['user_login_fieldset']['login_page_title'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Page Title'),
      '#default_value' => $config->get('login_page_title'),
    ];

    $form['user_login_fieldset']['email_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t("E-mail label"),
      '#default_value' => $config->get('email_label'),
    ];

    $form['user_login_fieldset']['email_description'] = [
      '#type' => 'textfield',
      '#title' => $this->t("E-mail Description"),
      '#default_value' => $config->get('email_description'),
    ];

    $form['user_login_fieldset']['password_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t("Password label"),
      '#default_value' => $config->get('password_label'),
    ];

    $form['user_login_fieldset']['password_description'] = [
      '#type' => 'textfield',
      '#title' => $this->t("Password Description"),
      '#default_value' => $config->get('password_description'),
    ];
    
    $form['user_login_fieldset']['login_header_text'] = [
      '#type' => 'textarea',
      '#title' => $this->t("Header Text"),
      '#default_value' => $config->get('login_header_text'),
    ];

    $form['user_login_fieldset']['login_footer_text'] = [
      '#type' => 'textarea',
      '#title' => $this->t("Footer Text"),
      '#default_value' => $config->get('login_footer_text'),
    ];

    $form['user_login_fieldset']['login_submit_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t("Submit label"),
      '#default_value' => $config->get('login_submit_label'),
    ];

    $form['user_login_fieldset']['login_redirect_path'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Login redirect path'),
      '#default_value' => $config->get('login_redirect_path'),
    ];

    $form['user_pass_fieldset'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('User Pass'),
    ];
    
    $form['user_pass_fieldset']['reset_page_title'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Page Title'),
      '#default_value' => $config->get('reset_page_title'),
    ];
    
    $form['user_pass_fieldset']['user_pass_header_text'] = [
      '#type' => 'textarea',
      '#title' => $this->t("Header Text"),
      '#default_value' => $config->get('user_pass_header_text'),
    ];

    $form['user_pass_fieldset']['user_pass_username_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t("Username or email address label"),
      '#default_value' => $config->get('user_pass_username_label'),
    ];
    
    $form['user_pass_fieldset']['user_pass_username_description'] = [
      '#type' => 'textarea',
      '#title' => $this->t("Username or email address Description"),
      '#default_value' => $config->get('user_pass_username_description'),
    ];
    
    $form['user_pass_fieldset']['user_pass_submit_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t("Submit label"),
      '#default_value' => $config->get('user_pass_submit_label'),
    ];

    $form['user_pass_fieldset']['user_pass_footer_text'] = [
      '#type' => 'textarea',
      '#title' => $this->t("Footer Text"),
      '#default_value' => $config->get('user_pass_footer_text'),
    ];

    $form['ask_question_fieldset'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Ask a question'),
    ];

    $form['ask_question_fieldset']['ask_question_filter_type'] = [
      '#type' => 'select',
      '#title' => $this->t("Filter Type"),
      '#options' => ['plain_text' => 'Plain text', 'full_html' => 'Full HTML', 'basic_html' => 'Basic HTML', 'restricted_html' => 'Restricted HTML'],
      '#default_value' => $config->get('ask_question_filter_type'),
    ];

    $form['ask_question_fieldset']['ask_question_submit_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t("Submit label"),
      '#default_value' => $config->get('ask_question_submit_label'),
    ];
    
    
    $form['restrict_country_fieldset'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Select Country to Restrict Access to Platform'),
    ];
    
    $country_manager = \Drupal::service('country_manager');
    $countrylist = $country_manager->getList();
    
    $form['restrict_country_fieldset']['restrict_country'] = [
      '#type' => 'select',
      '#title' => t('Country'),
      '#options' => $countrylist,
      '#default_value' => $config->get('restrict_country'),
      '#multiple' => true
    ];
    
    $form['our_story_restrict_country_fieldset'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Select Country to Restrict Access to Our Story'),
    ];
    
    $form['our_story_restrict_country_fieldset']['our_story_restrict_country'] = [
      '#type' => 'select',
      '#title' => t('Country'),
      '#options' => $countrylist,
      '#default_value' => $config->get('our_story_restrict_country'),
      '#multiple' => true
    ];

    $form['proceed_to_site_fieldset'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Proceed to site'),
    ];
    
    $form['proceed_to_site_fieldset']['link_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Link Text'),
      '#default_value' => $config->get('link_text'),
    ];

    $form['proceed_to_site_fieldset']['non_us_user_link'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Non Us User Page'),
      '#default_value' => $config->get('non_us_user_link'),
    ];

    $form['proceed_to_site_fieldset']['us_user_link'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Us User Page'),
      '#default_value' => $config->get('us_user_link'),
    ];
    
    $form['maintenance_page_fieldset'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Maintenance Page'),
    ];
    
    $form['maintenance_page_fieldset']['maintenance_page_link_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Link Text'),
      '#default_value' => $config->get('maintenance_page_link_text'),
    ];
    
    $form['maintenance_page_fieldset']['maintenance_page_link'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Link'),
      '#default_value' => $config->get('maintenance_page_link'),
    ];
    
    $form['home_welcome_learnmore_fieldset'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Home Welcome Learn More'),
    ];
    
    $form['home_welcome_learnmore_fieldset']['home_welcome_learnmore_link'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Link'),
      '#default_value' => $config->get('home_welcome_learnmore_link'),
    ];
    
     $form['certificate_of_attendance_fieldset'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Certificate of Attendance Access'),
    ];
    
    $form['certificate_of_attendance_fieldset']['certificate_of_attendance_emails'] = [
      '#type' => 'textarea',
      '#title' => $this->t("User emails to allow access"),
      '#description' => t('Enter one email per line'),
      '#default_value' => $config->get('certificate_of_attendance_emails'),
    ];
    
    

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    parent::submitForm($form, $form_state);

    $this->config('aps_custom.settings')
      ->set('register_page_title', $form_state->getValue('register_page_title'))
      ->set('register_username_label', $form_state->getValue('register_username_label'))
      ->set('register_username_description', $form_state->getValue('register_username_description'))
      ->set('register_email_label', $form_state->getValue('register_email_label'))
      ->set('register_email_description', $form_state->getValue('register_email_description'))
      ->set('register_email_weight', $form_state->getValue('register_email_weight'))
      ->set('register_pass1_label', $form_state->getValue('register_pass1_label'))
      ->set('register_pass2_label', $form_state->getValue('register_pass2_label'))
      ->set('register_password_weight', $form_state->getValue('register_password_weight'))
      ->set('register_submit_label', $form_state->getValue('register_submit_label'))
      ->set('register_redirect_path', $form_state->getValue('register_redirect_path'))
      ->set('login_page_title', $form_state->getValue('login_page_title'))
      ->set('email_label', $form_state->getValue('email_label'))
      ->set('email_description', $form_state->getValue('email_description'))
      ->set('password_label', $form_state->getValue('password_label'))
      ->set('password_description', $form_state->getValue('password_description'))
      ->set('password_description_view', $form_state->getValue('password_description_view'))
      ->set('login_submit_label', $form_state->getValue('login_submit_label'))
      ->set('login_header_text', $form_state->getValue('login_header_text'))
      ->set('login_footer_text', $form_state->getValue('login_footer_text'))
      ->set('reset_page_title', $form_state->getValue('reset_page_title'))
      ->set('user_pass_header_text', $form_state->getValue('user_pass_header_text'))
      ->set('user_pass_footer_text', $form_state->getValue('user_pass_footer_text'))
      ->set('login_redirect_path', $form_state->getValue('login_redirect_path'))
      ->set('user_pass_username_label', $form_state->getValue('user_pass_username_label'))
      ->set('user_pass_username_description', $form_state->getValue('user_pass_username_description'))
      ->set('user_pass_submit_label', $form_state->getValue('user_pass_submit_label'))
      ->set('ask_question_filter_type', $form_state->getValue('ask_question_filter_type'))
      ->set('ask_question_submit_label', $form_state->getValue('ask_question_submit_label'))
      ->set('restrict_country', $form_state->getValue('restrict_country'))
      ->set('our_story_restrict_country', $form_state->getValue('our_story_restrict_country'))
      ->set('link_text', $form_state->getValue('link_text'))
      ->set('non_us_user_link', $form_state->getValue('non_us_user_link'))
      ->set('us_user_link', $form_state->getValue('us_user_link'))
      ->set('maintenance_page_link_text', $form_state->getValue('maintenance_page_link_text'))
      ->set('maintenance_page_link', $form_state->getValue('maintenance_page_link'))
      ->set('home_welcome_learnmore_link', $form_state->getValue('home_welcome_learnmore_link'))
      ->set('certificate_of_attendance_emails', $form_state->getValue('certificate_of_attendance_emails'))
      ->save();

    drupal_flush_all_caches();
  }

}
