<?php

namespace Drupal\aps_custom\Plugin\Action;

use Drupal\node\Entity\Node;
use Drupal\views_bulk_operations\Action\ViewsBulkOperationsActionBase;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Action\ActionBase;
use Drupal\webform\WebformSubmissionForm;
use Drupal\webform\Entity\WebformSubmission;
use Mpdf\Mpdf;
use Swift_Attachment;
use Swift_Message;
use Swift_Mailer;
use Drupal\Core\Render\Markup;

/**
 * Content moderation publish node.
 *
 * @Action(
 *   id = "approve_certificate_of_attendance",
 *   label = @Translation("User (Approve)"),
 *   type = "webform_submission",
 *   confirm = TRUE
 * )
 */

class approveCertificateAction extends ActionBase {

  /**
   * {@inheritdoc}
   */
   public function execute($entity = NULL) {
    /** @var \Drupal\webform\WebformSubmissionInterface $entity */
    if ($entity != NULL) {
      if ($source_entity = $entity->getSourceEntity()) {
        $nid = $source_entity->id();
        if ($source_entity->hasField('field_event') && !$source_entity->get('field_event')->isEmpty()) {
          $field_event = $source_entity->get('field_event')->getValue();
          $event_id = isset($field_event[0]['target_id']) ? $field_event[0]['target_id'] : 0;
          $html = '';
          $data = $entity->getData();
          $event = $source_entity->get('field_event')->referencedEntities();
          $data['event_id'] = $event_id;
          $data['event_name'] = isset($event[0]) ? $event[0]->getTitle() : '';
          $data['event_date'] = isset($event[0]) ? $event[0]->field_dates->start_date->format('jS F Y') : '';
          $data['user_mail'] = $entity->getOwner()->getEmail();
          $data['username'] = $entity->getOwner()->getUsername();
          if ($entity->getOwner()->hasField('field_first_name') && !$entity->getOwner()->get('field_first_name')->isEmpty() && $entity->getOwner()->hasField('field_second_name') && !$entity->getOwner()->get('field_second_name')->isEmpty()) {
            $field_first_name = $entity->getOwner()->get('field_first_name')->getValue();
            $field_first_name = isset($field_first_name[0]['value']) ? $field_first_name[0]['value'] : '';
            $field_second_name = $entity->getOwner()->get('field_second_name')->getValue();
            $field_second_name = isset($field_second_name[0]['value']) ? $field_second_name[0]['value'] : '';
            $data['username'] = $field_first_name . ' ' . $field_second_name;
          }
          $entity->setElementData('certificate_sent', 1);
          $entity->save();
          $mpdf = new Mpdf(['tempDir' => 'sites/default/files/certificates', 'format' => 'A4-L', 'mode' => 'utf-8',
            'orientation' => 0,
            'margin_left' => 0,
            'margin_right' => 0,
            'margin_top' => 0,
            'margin_bottom' => 0,
            'margin_header' => 0,
            'margin_footer' => 0]);
          $mpdf->AddPage('L');
          $html = $this->getPDFHTML($data);
          $mpdf->WriteHTML($html);
          $pdf = $mpdf->Output('', 'S');
          // Create instance of Swift_Attachment with our PDF file.
          $this->prepareEmail($data, $pdf);
        }
      }
      else {
        $nid = NULL;
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function access($object, AccountInterface $account = NULL, $return_as_object = FALSE) {
    $result = $object->sticky->access('edit', $account, TRUE)
      ->andIf($object->access('update', $account, TRUE));

    return $return_as_object ? $result : $result->isAllowed();
  }

  public function prepareEmail($data, $pdf) {
    $mailManager = \Drupal::service('plugin.manager.mail');
    $module = 'aps_custom';
    $key = 'event_certificate';
    $to = $data['user_mail'];
    $body = '<p>Dear '. $data['username'] .',</p>';
    $body .= '<p>Thank you for attending our recent webinar.</p>';
    $body .= '<p>Your request for a certificate of attendance has been approved, please find your certificate attached.</p>';
    $body .= '<p>We’d like to thank you once again.</p>';
    $body .= '<p>Best regards<br>The Sanofi Genzyme Gaucher Team</p>';
    $params['message'] = Markup::create($body);
    //Attaching a file to the email
    $attachment = [
      'filecontent' => $pdf,
      'filename' => 'Insuline@100 - Certificate of Attendance.pdf', //File name
      'filemime' => 'application/pdf', //File mime type
    ];
    $params['attachments'] = $attachment;
    $langcode = \Drupal::currentUser()->getPreferredLangcode();
    $send = true;
    $result = $mailManager->mail($module, $key, $to, $langcode, $params, NULL, $send);
    if ($result['result'] !== true) {
      drupal_set_message(t('There was a problem sending your message and it was not sent.'), 'error');
    }
    else {
      drupal_set_message(t('Your message has been sent.'));
    }
  }

  public function getPDFHTML($data = NULL) {

  $html = '<body style="padding: 0;margin: 0; background:linear-gradient(45deg,  #bcbc1c 0%,#00a590 50%,#6980bf 100%);">
    <table class="outer-div" cellpadding="0" cellspacing="0" border="0" style="width:100%;text-align:center;background:linear-gradient(45deg,  #bcbc1c 0%,#00a590 50%,#6980bf 100%);min-height:100vh;height:100%;" align="right">
        <tr>
            <td class="heightm-auto" style="height:50px;"></td>
        </tr>
        <tr>
            <td align="center">
                <table class="full-bg" cellpadding="0" cellspacing="0" border="0" style="width:100%; text-align:center;">
                    <tr>
                        <td style="height:0px;"></td>
					
                    </tr>
                    <tr>
                        <td>
                            <table cellpadding="0" cellspacing="0" border="0" style="width:100%;">
                                <tr>
                                    <td class="fullwidth-m">
                                        <table cellpadding="0" cellspacing="0" border="0" style="width:100%;">
                                            <tr>
                                                <td class="logo">
                                                    <a href="index.html"><img src="'. drupal_get_path('module', 'aps_custom') .'/img/logo.svg" width="322" height="89" alt="logo"></a>
                                                </td>
                                            </tr>
                                            
                                            <tr>
                                                <td class="box-grey">
                                                    <table cellpadding="0" cellspacing="0" border="0" style="width:100%;">
                                                        <tr>
                                                            <td colspan="3" class="heightm-auto" style="height:50px;"></td>
                                                        </tr>
                                                        <tr>
                                                            <td class="fullwidth-m" style="width:140px"></td>
                                                            <td class="paddingm-15" align="center" style="text-align:center;">
                                                                <table cellpadding="0" cellspacing="0" border="0" style="width:100%;">
                                                                    <tr>
                                                                        <td class="font-m20" style="color: #ffffff;font-size: 50px;font-family: Roboto, sans-serif; line-height:1; font-weight:bold;text-align:center; ">CERTIFICATE OF ATTENDANCE </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="height:35px;"></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="font-m16" style="font-size:40px; color:#ffffff;font-family: Roboto, sans-serif; line-height:1;padding: 0 20px; text-align:center;font-weight: 300;">This is to certify that </td>
                                                                    </tr>
																	<tr>
                                                                        <td style="height:55px;"></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="font-m16" style="font-size:28px; color:#ffffff;font-family: Roboto, sans-serif; line-height:28px;padding: 0 20px;text-align:center; border-bottom: 2px solid #ffffff;text-transform: capitalize;">' . $data['name'] . '</td>
                                                                    </tr>
																	<tr>
                                                                        <td style="height:35px;"></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="font-m16" style="font-size:40px; color:#ffffff;font-family: Roboto, sans-serif; line-height:1;padding: 0 20px; text-align:center;font-weight: 300;">attended </td>
                                                                    </tr>
																	<tr>
                                                                        <td style="height:25px;"></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="font-m16" style="font-size:25px; color:#ffffff;font-family: Roboto, sans-serif; line-height:28px;padding: 0 20px;text-align:center;font-weight:bold;"> ‘INSULIN@100: Discovery. Transformation. Legacy’ <br>A live webinar.</td>
                                                                    </tr>
																	<tr>
                                                                        <td style="height:25px;"></td>
                                                                    </tr>
																	<tr>
                                                                        <td class="font-m16" style="font-size:40px; color:#ffffff;font-family: Roboto, sans-serif; line-height:1;padding: 0 20px; text-align:center;font-weight: 300;">Friday 05 March 2021 </td>
                                                                    </tr>
																	<tr>
                                                                        <td style="height:30px;"></td>
                                                                    </tr>
																	<tr>
                                                                        <td class="font-m16" style="font-size:18px; color:#ffffff;font-family: Roboto, sans-serif; line-height:1;padding: 0 20px; text-align:center;font-weight:bold;">Nadia Ait-Aissa, MD </td>
                                                                    </tr>
																	<tr>
                                                                        <td class="font-m16" style="font-size:14px; color:#ffffff;font-family: Roboto, sans-serif; line-height:1;padding: 0 20px; text-align:center;font-weight:800;">Global Head of Scientific Engagement and Communication </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="height:35px;"></td>
                                                                    </tr>


                                                                </table>
                                                            </td>
                                                            <td class="fullwidth-m" style="width:140px"></td>
                                                        </tr>
                                                    </table>
													
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tfoot>
		<tr>
		    <td>
			    <table style="width:100%;">
				    <tr>
					   <td style="width:30px;"></td>
					   <td style="font-size:16px; color:#ffffff;font-family: Roboto, sans-serif; line-height:1;padding: 0; text-align:left;font-weight: 300;">This scientific educational meeting was organised by Sanofi</td>
					   <td style="width:15px;"></td>
					   <td style="text-align:right;"><img src="'. drupal_get_path('module', 'aps_custom') .'/img/footer-logo.png" alt=""></td>
					   <td style="width:30px;"></td>
					</tr>
				
				</table>
			</td>
		</tr>
		</tfoot>
    </table>
</body>';
  
  return $html;

  }
}