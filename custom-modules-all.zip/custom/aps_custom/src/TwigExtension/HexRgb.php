<?php 
namespace Drupal\aps_custom\TwigExtension;

 
class HexRgb extends \Twig_Extension {    
 
  /**
   * Generates a list of all Twig filters that this extension defines.
   */
  public function getFilters() {
    return [
      new \Twig_SimpleFilter('hexrgb', array($this, 'hex_to_rgb')),
    ];
  }
 
  /**
   * Gets a unique identifier for this Twig extension.
   */
  public function getName() {
    return 'aps_custom.hexrgb';
  }
 
  public function hex_to_rgb($hex, $opacity = 0) {
    
    list($r, $g, $b) = sscanf($hex, "#%02x%02x%02x");
    $output = "rgba($r, $g, $b, $opacity)";
    return $output;
  }
 
}
