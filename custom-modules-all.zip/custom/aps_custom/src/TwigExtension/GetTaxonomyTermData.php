<?php 
namespace Drupal\aps_custom\TwigExtension;

 
class GetTaxonomyTermData extends \Twig_Extension {    
 
  /**
   * Generates a list of all Twig filters that this extension defines.
   */
  public function getFilters() {
    return [
      new \Twig_SimpleFilter('get_taxonomy_term_data', array($this, 'get_taxonomy_term_data')),
    ];
  }
 
  /**
   * Gets a unique identifier for this Twig extension.
   */
  public function getName() {
    return 'aps_custom.get_taxonomy_term_data';
  }
 
  public function get_taxonomy_term_data($data = []) {
    $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadByProperties($data);
    return $term;
  }
 
}
