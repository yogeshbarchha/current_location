<?php 
namespace Drupal\aps_custom\TwigExtension;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\user\Entity\User;

 
class ProceedToSiteUrl extends \Twig_Extension {    
 
  /**
   * Generates a list of all Twig filters that this extension defines.
   */
  public function getFilters() {
    return [
      new \Twig_SimpleFilter('proceed_to_site_url', array($this, 'proceed_to_site_url')),
    ];
  }
 
  /**
   * Gets a unique identifier for this Twig extension.
   */
  public function getName() {
    return 'aps_custom.proceed_to_site_url';
  }
 
  public function proceed_to_site_url() {
    $link = '';
    $config = \Drupal::config('aps_custom.settings');
    $user = User::load(\Drupal::currentUser()->id());
    if ($user->hasField('field_country') && !$user->get('field_country')->isEmpty() && $config->get('link_text')) {
       $config = \Drupal::config('aps_custom.settings');
       $link_text = $config->get('link_text');
       $us_user_link = $config->get('us_user_link');
       $non_us_user_link = $config->get('non_us_user_link');
       $country = $user->get('field_country')->getValue();
       $country_code = isset($country[0]['value']) ? $country[0]['value'] : '';
       $restricted_country = ($config->get('restrict_country')) ? $config->get('restrict_country') : [];
       if (in_array($country_code, $restricted_country) && $us_user_link) {
        $link = Link::fromTextAndUrl($link_text, Url::fromUserInput($us_user_link))->toRenderable();
      }
      elseif ($non_us_user_link) {
        $link = Link::fromTextAndUrl($link_text, Url::fromUserInput($non_us_user_link))->toRenderable(); 
      }
    }
    return $link;
  }
 
}
