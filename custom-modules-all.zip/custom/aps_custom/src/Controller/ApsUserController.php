<?php

namespace Drupal\aps_custom\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Listens to the dynamic route events.
 */
class ApsUserController extends ControllerBase {
    
  /**
  * {@inheritdoc}
  */
  function userRegisterTitle() {
    $config = \Drupal::config('aps_custom.settings');
    $title = ($config->get('register_page_title')) ? $config->get('register_page_title') : t('Registration');
    return $title;  
  }
  
  /**
  * {@inheritdoc}
  */
  function userLoginTitle() {
    $config = \Drupal::config('aps_custom.settings');
    $title = ($config->get('login_page_title')) ? $config->get('login_page_title') : t('Login');
    return $title;
  }
  
  /**
  * {@inheritdoc}
  */
  function userResetTitle() {
    $config = \Drupal::config('aps_custom.settings');
    $title = ($config->get('reset_page_title')) ? $config->get('reset_page_title') : t('Reset');
    return $title;
  }
  
  /**
  * {@inheritdoc}
  */
  function userProfileTitle() {
    $title = t('User Profile');
    return $title;
  }
}