<?php



namespace Drupal\aps_certificate\Controller;

use Drupal\Core\Controller\ControllerBase;
use Mpdf\Mpdf;
use Mpdf\Config\ConfigVariables;
use Mpdf\Config\FontVariables;


/**
 *
 */
class Certificate extends ControllerBase {

  /**
   *
   */
  public function download() {
   
   $defaultConfig = (new ConfigVariables())->getDefaults();
    $fontDirs = $defaultConfig['fontDir'];
          
    $defaultFontConfig = (new FontVariables())->getDefaults();
    $fontData = $defaultFontConfig['fontdata'];
    
    $mpdf = new Mpdf(['tempDir' => 'sites/default/files/certificates', 'format' => 'A4', 'mode' => 'utf-8',
            'orientation' => L,
            'margin_left' => 0,
            'margin_right' => 0,
            'margin_top' => 0,
            'margin_bottom' => 0,
            'margin_header' => 0,
            'margin_footer' => 0,
            // 'setAutoBottomMargin' => 0,
            'fontDir' => array_merge($fontDirs, [
                drupal_get_path('module', 'aps_certificate') . '/fonts',
             ]),
             'fontdata' => $fontData + [
               'avantgarde' => [
                 'R' => 'ITCAvantGardeStd-Bk.ttf',
                 'B' => 'ITCAvantGardeStd-Bold.ttf',
               ]
             ],
           'default_font' => 'avantgarde'
          ]);

    // $mpdf->AddPage('L');
    $stylesheet = file_get_contents(drupal_get_path('module', 'aps_certificate').'/css/aps_certificate.css'); // external css
    $html = $this->getPDFHTML($data);
    $mpdf->WriteHTML($stylesheet,1);
    $mpdf->WriteHTML($html,2);
    $pdf = $mpdf->Output('aps_certificate.pdf', 'I');

    // $build = [
    //   '#markup' => $this->t('Hello World!'),
    // ];
    return $pdf;
  }

  public function getPDFHTML($data = NULL) {    
    $html = '';
    
    $html = '<body style="margin:0;padding:0;">
    <table class="outer-div" cellpadding="0" cellspacing="0" border="0" style="width:100%;height:100%;">
        
	
       
            <tr>
                <th>
                    <table cellpadding="0" cellspacing="0" style="width: 100%;background:linear-gradient(45deg,  #bcbc1c 0%,#00a590 50%,#6980bf 100%);">
                       <tr>
                            <td>
                               <table cellpadding="0" cellspacing="0" style="width: 100%;">
                                    <tr>
                                        <td style="width:50%;vertical-align: top;text-align:left;">
                                            <img style="border:0px;outline:none;" alt="" src="/modules/custom/aps_certificate/images/header-img.png" />
                                        </td>
            							<td style="width:20%;"></td>
                                        <td style="width:30%;font-family: avantgarde;vertical-align: middle;  text-align:left;font-size:70px;color:#fff;text-transform:uppercase;font-weight:bold;">
                                           CERTIFICATE <br/> OF ATTENDANCE
                                        </td>
            						
                                    </tr>
                                </table>
                            </td>
                            <td style="width:80px;"></td>
                        </tr>
                    </table>
                </th>
            </tr>
        
			
        
		<tr>
            <td align="center">
                <table class="full-bg" cellpadding="0" cellspacing="0" border="0" style="width:100%; text-align:center;background-color:#fff;color:#525ca3;">
                    <tr>
                        <td style="height:186px;"></td>					
                    </tr>
                    <tr>
                        <td>
                            <table cellpadding="0" cellspacing="0" border="0" style="width:100%;">
                                <tr>
								   <td style="width:15%;"></td>
                                    <td class="fullwidth-m" style="width:70%;">
                                        <table cellpadding="0" cellspacing="0" border="0" style="width:100%;">                                           
                                                                                      
											<tr>
												<td style="width:100px"></td>
												<td class="paddingm-15" align="center" style="text-align:center;">
													<table cellpadding="0" cellspacing="0" border="0" style="width:100%;">
														
														
														<tr>
															<td class="font-m16" style="font-size:70px; color:#525ca3;font-family: avantgarde; line-height:1; text-align:center;font-weight: 300;">This is to certify that </td>
														</tr>
														<tr>
															<td style="height:70px;"></td>
														</tr>
														<tr>
															<td class="font-m16" style="font-size:50px; color:#525ca3;font-family: avantgarde; line-height:normal;text-align:center; border-bottom: 3px solid #00a590;text-transform:capitalize;color:#00a590;"> User name</td>
														</tr>
														<tr>
															<td style="height:60px;"></td>
														</tr>
														<tr>
															<td class="font-m16" style="font-size:70px; color:#525ca3;font-family: avantgarde; line-height:1;text-align:center;font-weight: 300;">attended </td>
														</tr>
														<tr>
															<td style="height:50px;"></td>
														</tr>
														<tr>
															<td class="font-m16" style="font-size:50px; color:#525ca3;font-family: avantgarde; line-height:normal;text-align:center;font-weight:bold;"> Basal Insulin Therapy: Starting a New Decade. <br>A live webinar.</td>
														</tr>
														<tr>
															<td style="height:40px;"></td>
														</tr>
														<tr>
															<td class="font-m16" style="font-size:50px; color:#525ca3;font-family: avantgarde; line-height:1; text-align:center;font-weight: 300;">Tuesday 02 February 2021 </td>
														</tr>
														<tr>
															<td style="height:150px;"></td>
														</tr>
														<tr>
															<td class="font-m16" style="font-size:40px; color:#525ca3;font-family: avantgarde; line-height:1; text-align:center;font-weight:bold;">Nadia Ait-Aissa, MD </td>
														</tr>
														<tr>
															<td style="height:5px;"></td>
														</tr>
														<tr>
															<td class="font-m16" style="font-size:30px; color:#525ca3;font-family: avantgarde; line-height:1; text-align:center;font-weight:500;">Global Head of Scientific Engagement and Communication</td>
														</tr>
														


													</table>
												</td>
												<td style="width:100px"></td>
											</tr>
										
                                        </table>
                                    </td>
									<td style="width:15%;"></td>
                                </tr>
                                
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td style="height:120px;"></td>					
                    </tr>
				</table>
            </td>
        </tr>
	    <tr>
				<td>
					<table cellpadding="0" cellspacing="0" style="width:100%;background-color:#00a590;">
					    <tr>
						   <td style="height:50px;" colspan="5"></td>
						</tr>
						<tr>
						   <td style="width:80px;"></td>
						   <td style="font-size:30px;vertical-align: middle; color:#ffffff;font-family: avantgarde; line-height:1;padding: 0; text-align:left;font-weight: 400;">This scientific educational meeting was organised by Sanofi</td>
						   <td style="width:15px;"></td>
						   <td style="text-align:right;vertical-align: middle;"><img src="/modules/custom/aps_certificate/images/footer-logo.png" alt=""></td>
						   <td style="width:80px;"></td>
						</tr>
						<tr>
						   <td style="height:50px;" colspan="5"></td>
						</tr>
					</table>
				</td>
			</tr>
        
	</table>
</body>
';
  
    return $html;
  }

}
