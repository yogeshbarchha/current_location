(function ($) {
  "use strict";
  Drupal.behaviors.apsMatomoAnalyticsLivestream = {
    attach: function (context, settings) {
      var $body = $('body');

      /**
       * Register livestream players on Matomo.
       */
      window.piwikMediaAnalyticsAsyncInit = function () {
        var $MA = window.Piwik.MediaAnalytics;

        function livestreamPlayer($node, $mediaType) {
          // Detects initial load of Livestream's iframe.
          $node.on('load', function () {
            var $n = $(this);
            $n.trigger('play');
          });
        }

        livestreamPlayer.scanForMedia = function($documentOrElement) {
          var $iframe = $('iframe.livestream-iframe', $documentOrElement),
              $nodeTitle = drupalSettings.aps_matomo.apsMatomo.node_title;

          if ($iframe.length) {
            $iframe.each(function ($i) {
              var $item = $(this);

              if (!$item.hasClass('aps-matomo-livestream-processed')) {
                $item.attr('data-matomo-title', $nodeTitle);
                $item.attr('data-matomo-resource', $(location).attr('href'));

                // Register player in Matomo.
                Drupal.behaviors.apsMatomoAnalytics.registerPlayer($item, $MA.mediaType.VIDEO);

                $item.addClass('aps-matomo-livestream-processed');
              }
            });
          }
        };

        // Adding the newly created player to the Media Analytics tracker.
        $MA.addPlayer('apsMatomoLivestream', livestreamPlayer);
      };

      /**
       * Install event managers for general page events
       * (tab/browser is closed, change tab/app,...).
       */
      if ($body.length && !$body.hasClass('aps-matomo-page-processed')) {
        // Detect tab/browser is closed.
        $(window).on('beforeunload', function () {
          var $items = $('.aps-matomo-processed');
          if ($items.length) {
            $items.each(function () {
              var $item = $(this);
              $item.trigger('ended');
            });
          }
        });

        // Detect if tab is active or not.
        $(window).on('focus blur pageshow pagehide', function ($e) {
          var $items = $('.aps-matomo-processed');
          if ($items.length) {
            $items.each(function () {
              var $item = $(this);
              switch($e.type) {
                case 'focus':
                  if ($item.attr('prev-action') === 'pause') {
                    $item.trigger('play');
                  }
                  break;
                case 'pageshow':
                  $item.trigger('play');
                  break;
                case 'blur':
                  if (!$(':focus').hasClass('aps-matomo-processed') &&
                      $item.attr('prev-action') === 'play') {
                    $item.trigger('pause');
                  }
                  break;
                case 'pagehide':
                  $item.trigger('pause');
                  break;
              }
            });
          }
        });

        // Detect if window is resized.
        $(window).on('resize', function ($e) {
          var $items = $('.aps-matomo-processed');
          if ($items.length) {
            $items.each(function () {
              var $item = $(this);
              $item.trigger('resized');
            });
          }
        });

        $body.addClass('aps-matomo-page-processed');
      }
    }
  };
}(jQuery));
