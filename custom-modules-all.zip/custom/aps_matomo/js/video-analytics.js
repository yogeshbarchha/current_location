(function ($) {
  "use strict";
  Drupal.behaviors.apsMatomoAnalytics = {
    /**
     * Register an APS Matomo instance for player.
     */
    registerPlayer: function($node, $mediaType) {
      if ($node.hasPlayerInstance) {
        // Prevent creating multiple trackers for the same media
        // when scanning for media multiple times.
        return;
      }

      $node.hasPlayerInstance = true;
      $node.addClass('aps-matomo-processed');

      var $MA = window.Piwik.MediaAnalytics,
          $actualResource = ($MA.element.getAttribute($node, 'src') ? '' : $node.attr('data-matomo-resource')),
          $resource = $MA.element.getMediaResource($node, $actualResource),
          $tracker = new $MA.MediaTracker('apsMatomo', $mediaType, $resource),
          $userId = drupalSettings.aps_matomo.apsMatomo.user_id,
          $nodeId = drupalSettings.aps_matomo.apsMatomo.node_id,
          $nodeTitle = drupalSettings.aps_matomo.apsMatomo.node_title;

      // For video you should detect the width and height.
      $tracker.setWidth($node.width());
      $tracker.setHeight($node.height());
      $tracker.setFullscreen(false);
      $tracker.setMediaTitle($nodeTitle);

      $node.on('initialize', function($e) {
        var $n = $(this),
            $action = $e.type;

        // Here we make sure to send an initial tracking request for this media.
        // This basically tracks an impression for this media.
        $tracker.trackUpdate();

        Drupal.behaviors.apsMatomoAnalytics.logEvent('initialize');
      });

      $node.on('play', function($e) {
        var $n = $(this),
            $action = $e.type;
        $n.attr('prev-action', $action);
        $tracker.play();
        Drupal.behaviors.apsMatomoAnalytics.logEvent($action);
      });

      $node.on('pause', function($e) {
        var $n = $(this),
            $action = $e.type;
        $n.attr('prev-action', $action);
        $tracker.pause();
        Drupal.behaviors.apsMatomoAnalytics.logEvent($action);
      });

      $node.on('ended', function($e) {
        var $action = $e.type;
        $tracker.finish();
        Drupal.behaviors.apsMatomoAnalytics.logEvent($action);
      });

      // For videos it might be useful to listen to the resize event to detect a
      // changed video width/height.
      $node.on('resized', function ($e) {
        var $n = $(this),
            $action = $e.type;
        $tracker.setWidth($n.width());
        $tracker.setHeight($n.height());
        Drupal.behaviors.apsMatomoAnalytics.logEvent($action);
      });

      $node.trigger('initialize');
    },

    /**
     * Log event for player.
     */
    logEvent: function($eventName, $message = '') {
      var $currentDate,
          $logEnabled = false;

      if ($logEnabled) {
        $currentDate = '[' + new Date().toLocaleString() + ']';
        if ($message.length) {
          $message = '(' + $message + ')';
        }
        console.log('APS MATOMO ' + $currentDate + ': ' + $eventName + ' event ' + $message);
      }
    }
  };
}(jQuery));
