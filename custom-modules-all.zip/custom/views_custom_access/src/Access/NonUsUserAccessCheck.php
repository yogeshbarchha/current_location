<?php

namespace Drupal\views_custom_access\Access;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Routing\Access\AccessInterface;
use Drupal\Core\Session\AccountInterface;
use Symfony\Component\Routing\Route;
use Symfony\Component\HttpFoundation\Request;
use Drupal\user\Entity\User;

/**
 * Class MyCustomAccessCheck
 * @package Drupal\mymodule\Access
 */
class NonUsUserAccessCheck implements AccessInterface
{
  /**
   * @return string
   */
  public function appliesTo()
  {
    return 'nonususer_access_check';
  }

  /**
   * @param Route $route
   * @param Request $request
   * @param AccountInterface $account
   * @return AccessResult|\Drupal\Core\Access\AccessResultAllowed
   */
  public function access(AccountInterface $account)
  {
    // an example
    $user = User::load($account->id());
    $roles = $account->getRoles();
    if (in_array('administrator', $roles)) {
      return AccessResult::allowed();
    }
    if (in_array('authenticated', $roles) && $user->hasField('field_country') && !$user->get('field_country')->isEmpty()) {
      $config = \Drupal::config('aps_custom.settings');
      $country = $user->get('field_country')->getValue();
      $country_code = isset($country[0]['value']) ? $country[0]['value'] : '';
      $restricted_country = ($config->get('restrict_country')) ? $config->get('restrict_country') : [];
      if (!in_array($country_code, $restricted_country)) {
        return AccessResult::allowed();
      }
    }
    return AccessResult::forbidden();
  }

}