<?php


namespace Drupal\views_custom_access\Plugin\views\access;

use Drupal\views\Plugin\views\access\AccessPluginBase;
use Drupal\Core\Session\AccountInterface;
use Symfony\Component\Routing\Route;
use Drupal\user\Entity\User;


/**
 * Class ViewsCustomAccess
 *
 * @ingroup views_access_plugins
 *
 * @ViewsAccess(
 *     id = "ViewsCustomAccess",
 *     title = @Translation("Non US access for views"),
 *     help = @Translation("Add custom logic to access() method"),
 * )
 */
class ViewsCustomAccess extends AccessPluginBase
{
  
    /**
     * {@inheritdoc}
     */
    public function summaryTitle()
    {
        return $this->t('Non US access for views Settings');
    }


    /**
     * {@inheritdoc}
     */
    public function access(AccountInterface $account)
    {   
        return TRUE;
    }


    /**
     * {@inheritdoc}
     */
    public function alterRouteDefinition(Route $route)
    {
        $route->setRequirement('_custom_access', 'views_custom_access.nonususer_access_check::access');
    }
}
?>